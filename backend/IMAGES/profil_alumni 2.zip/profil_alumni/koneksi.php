<?php
$host = "localhost"; // Sesuaikan jika bukan localhost
$user = "root"; // Default XAMPP tanpa password
$pass = ""; // Jika pakai password, isi di sini
$db   = "profil_alumni"; // Sesuaikan dengan database yang digunakan

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi Gagal! " . $conn->connect_error);
}
?>
