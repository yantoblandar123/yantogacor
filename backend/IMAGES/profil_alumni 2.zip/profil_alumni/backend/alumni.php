<?php
include 'koneksi.php'; // Memanggil file koneksi

// Inisialisasi filter
$filter_tahun_lulus = isset($_GET['tahun_lulus']) ? $_GET['tahun_lulus'] : '';
$filter_jurusan = isset($_GET['jurusan']) ? $_GET['jurusan'] : '';

// Query dasar untuk mengambil data alumni
$sql = "SELECT * FROM alumni WHERE 1=1";

// Tambahkan filter jika ada
if (!empty($filter_tahun_lulus)) {
    $sql .= " AND tahun_lulus = '$filter_tahun_lulus'";
}

if (!empty($filter_jurusan)) {
    $sql .= " AND jurusan = '$filter_jurusan'";
}

$sql .= " ORDER BY tahun_lulus DESC";
$result = $conn->query($sql);

// Ambil daftar jurusan untuk dropdown filter
$sql_jurusan = "SELECT DISTINCT jurusan FROM alumni WHERE jurusan IS NOT NULL AND jurusan != ''";
$result_jurusan = $conn->query($sql_jurusan);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Alumni</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .foto-alumni {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }
        .alumni-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .alumni-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 10px;
            width: 250px;
            text-align: center;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
            cursor: pointer;
            text-decoration: none;
            color: black;
        }
        .filter-container {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h2>Data Alumni SMAN 1 Montong</h2>
    </header>

    <main>
        <div class="filter-container">
            <form method="GET" action="">
                <label for="tahun_lulus">Tahun Lulus:</label>
                <input type="date" id="tahun_lulus" name="tahun_lulus" value="<?= htmlspecialchars($filter_tahun_lulus) ?>">

                <label for="jurusan">Jurusan:</label>
                <select id="jurusan" name="jurusan">
                    <option value="">Semua</option>
                    <?php while ($jurusan = $result_jurusan->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($jurusan['jurusan']) ?>" 
                            <?= $filter_jurusan == $jurusan['jurusan'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($jurusan['jurusan']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <button type="submit">Filter</button>
            </form>
        </div>

        <div class="alumni-container">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $foto_path = !empty($row["foto_profil"]) ? 'uploads/' . htmlspecialchars($row["foto_profil"]) : 'IMAGES/default.png';
                    echo '<a href="profil_alumni.php?nisn=' . htmlspecialchars($row["nisn"]) . '" class="alumni-card">';
                    echo '<img src="' . htmlspecialchars($row["foto_profil"]) . '" alt="Foto alumni" class="foto-alumni">';
                    echo '<h3>' . htmlspecialchars($row["nama"]) . '</h3>';
                    echo '<p>NISN: ' . htmlspecialchars($row["nisn"]) . '</p>';
                    echo '<p>Kelas: ' . htmlspecialchars($row["kelas"]) . '</p>';
                    echo '<p>Jurusan: ' . htmlspecialchars($row["jurusan"]) . '</p>';
                    echo '<p>Tahun Lulus: ' . htmlspecialchars($row["tahun_lulus"]) . '</p>';
                    echo '<p>Email: ' . htmlspecialchars($row["email"]) . '</p>';
                    echo '<p>No HP: ' . htmlspecialchars($row["no_hp"]) . '</p>';
                    echo '</a>';
                }
            } else {
                echo "<p>Tidak ada data alumni yang sesuai filter.</p>";
            }
            ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 Data Alumni SMAN 1 Montong</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
