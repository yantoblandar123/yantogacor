<?php
$host = "localhost"; // Sesuaikan dengan host database
$user = "root"; // Sesuaikan dengan username database
$pass = ""; // Sesuaikan dengan password database, kosongkan jika tidak ada
$dbname = "profil_alumni"; // Ganti dengan nama database yang sesuai

$conn = new mysqli($host, $user, $pass, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
