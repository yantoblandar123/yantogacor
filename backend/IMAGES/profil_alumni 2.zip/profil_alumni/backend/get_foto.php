<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT foto_tamu FROM alumni WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $foto_path = "backend/uploads/" . $row["foto"];

        if (file_exists($foto_path)) {
            header("Content-Type: image/png");
            readfile($foto_path);
        } else {
            echo "File tidak ditemukan.";
        }
    } else {
        echo "Data tidak ditemukan.";
    }
}

$conn->close();
?>
