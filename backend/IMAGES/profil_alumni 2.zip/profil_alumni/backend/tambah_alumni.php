<?php
session_start();

// Pastikan tidak ada output sebelum session_start
ob_start();

// Periksa apakah file koneksi ada
if (!file_exists('koneksi.php')) {
    die("Error: File koneksi.php tidak ditemukan.");
}

// Sertakan file koneksi
include 'koneksi.php';

// Pastikan koneksi berhasil
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Tangkap data dari form
$nama = isset($_POST['nama']) ? $_POST['nama'] : '';
$nisn = isset($_POST['nisn']) ? $_POST['nisn'] : '';
$tempat_lahir = isset($_POST['tempat_lahir']) ? $_POST['tempat_lahir'] : '';
$tanggal_lahir = isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : '';
$kelas = isset($_POST['kelas']) ? $_POST['kelas'] : '';
$jurusan = isset($_POST['jurusan']) ? $_POST['jurusan'] : '';
$tahun_lulus = isset($_POST['tahun_lulus']) ? $_POST['tahun_lulus'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$no_hp = isset($_POST['no_hp']) ? $_POST['no_hp'] : '';
$alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
$biodata = isset($_POST['biodata']) ? $_POST['biodata'] : '';
$nama_ayah = isset($_POST['nama_ayah']) ? $_POST['nama_ayah'] : '';
$pekerjaan_ayah = isset($_POST['pekerjaan_ayah']) ? $_POST['pekerjaan_ayah'] : '';
$nama_ibu = isset($_POST['nama_ibu']) ? $_POST['nama_ibu'] : '';
$pekerjaan_ibu = isset($_POST['pekerjaan_ibu']) ? $_POST['pekerjaan_ibu'] : '';
$no_hp_ortu = isset($_POST['no_hp_ortu']) ? $_POST['no_hp_ortu'] : '';

// Upload Foto Profil
// Upload Foto Profil
$foto_profil = "IMAGES/default.png"; // Set gambar default

if (!empty($_FILES['foto_profil']['name'])) {
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true); // Buat folder jika belum ada
    }
    $foto_profil = $target_dir . basename($_FILES["foto_profil"]["name"]);
    if (!move_uploaded_file($_FILES["foto_profil"]["tmp_name"], $foto_profil)) {
        $foto_profil = "IMAGES/default.png"; // Jika upload gagal, tetap gunakan gambar default
    }
}


// Query untuk menyimpan data
$sql = "INSERT INTO alumni (nama, nisn, tempat_lahir, tanggal_lahir, kelas, jurusan, tahun_lulus, email, no_hp, alamat, biodata, foto_profil, nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, no_hp_ortu) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error pada query: " . $conn->error);
}

$stmt->bind_param("sssssssssssssssss", $nama, $nisn, $tempat_lahir, $tanggal_lahir, $kelas, $jurusan, $tahun_lulus, $email, $no_hp, $alamat, $biodata, $foto_profil, $nama_ayah, $pekerjaan_ayah, $nama_ibu, $pekerjaan_ibu, $no_hp_ortu);

if ($stmt->execute()) {
    echo "<script>alert('Data berhasil disimpan!'); window.location.href = 'alumni.php';</script>";
} else {
    echo "<script>alert('Gagal menyimpan data: " . $stmt->error . "'); window.history.back();</script>";
}

// Tutup koneksi
$stmt->close();
$conn->close();
ob_end_flush();
?>
