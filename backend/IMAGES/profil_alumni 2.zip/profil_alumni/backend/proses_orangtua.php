<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pastikan ID Alumni dikirim
    if (!isset($_POST['id_alumni']) || empty($_POST['id_alumni'])) {
        die("Error: ID Alumni tidak valid atau tidak dikirim.");
    }

    // Ambil ID Alumni
    $id_alumni = $_POST['id_alumni'];

    // Ambil data dari form
    $nama_ayah = isset($_POST['nama_ayah']) ? $_POST['nama_ayah'] : '';
    $pekerjaan_ayah = isset($_POST['pekerjaan_ayah']) ? $_POST['pekerjaan_ayah'] : '';
    $nama_ibu = isset($_POST['nama_ibu']) ? $_POST['nama_ibu'] : '';
    $pekerjaan_ibu = isset($_POST['pekerjaan_ibu']) ? $_POST['pekerjaan_ibu'] : '';
    $no_hp_ortu = isset($_POST['no_hp_ortu']) ? $_POST['no_hp_ortu'] : '';

    // Simpan data ke database
    if ($conn) {
        $sql = "INSERT INTO orang_tua (id_alumni, nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, no_hp_ortu) 
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("isssss", $id_alumni, $nama_ayah, $pekerjaan_ayah, $nama_ibu, $pekerjaan_ibu, $no_hp_ortu);
            if ($stmt->execute()) {
                echo "Data orang tua berhasil disimpan.";
                header("Location: sukses.php"); // Redirect ke halaman sukses
                exit();
            } else {
                echo "Terjadi kesalahan: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Gagal menyiapkan statement: " . $conn->error;
        }
        $conn->close();
    } else {
        echo "Koneksi ke database gagal.";
    }
} else {
    echo "Metode request tidak valid.";
}
?>
