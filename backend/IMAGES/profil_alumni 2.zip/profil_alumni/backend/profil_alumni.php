<?php
include 'koneksi.php'; // Memanggil file koneksi

// Periksa koneksi
if (!$conn) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}

// Ambil ID alumni dari URL
$id_alumni = isset($_GET['id_alumni']) ? mysqli_real_escape_string($conn, $_GET['id_alumni']) : 0;

// Query untuk mengambil data alumni berdasarkan ID
$sql = "SELECT * FROM alumni WHERE id_alumni = '$id_alumni'";
$result = mysqli_query($conn, $sql);
$alumni = mysqli_fetch_assoc($result);

// Jika data tidak ditemukan, alihkan kembali ke halaman utama
if (!$alumni) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Alumni - <?php echo htmlspecialchars($alumni['nama']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header id="header">
    <section id="awokawok">
        <a href="#"><img src="IMAGES/logo provinsi.png" class="logo" width="150" height="150" alt=""></a>
        <div class="Montong">
            <h3>PEMERINTAH PROVINSI JAWA TIMUR</h3>
            <h3>DINAS PENDIDIKAN</h3>
            <h6>Cabang Dinas Pendidikan Wilayah Bojonegoro</h6>
            <h6>(Kabupaten Bojonegoro-Kabupaten Tuban)</h6>
            <h3>SEKOLAH MENENGAH ATAS NEGERI 1 MONTONG</h3>
            <h5>Jl.Raya Tanggulangin Km 1 Montong Tuban, Telp.(0356)4214568</h5>
            <h6>E-mail : sma_negeri1montong@yahoo.com Website : smansamontong.sch.id</h6>
        </div>
        <a href="#"><img src="IMAGES/logo_sekolah.png" class="logo" width="150" height="150" alt=""></a>
    </section>

    <nav id="navbar-container">
        <ul id="navbar">
            <li><a href="index.php">Home</a></li>
            <li><a class="active" href="profil_alumni.php">profil alumni</a></li>
            <li><a href="tentang.html">tentang kami</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </nav>
</header>


<section id="prodetail" class="section-p1">
    <div class="s-pro-img">
        <img src="<?php echo htmlspecialchars($alumni['foto_profil']); ?>" width="100%" id="gmbrutm" alt="Foto Alumni">
    </div>

    <div class="s-pro-detail">
        <h4><?php echo htmlspecialchars($alumni['nama']); ?></h4>
        <h6>Tahun Lulus: <?php echo htmlspecialchars($alumni['tahun_lulus']); ?></h6>
        <p><strong>NISN:</strong> <?php echo htmlspecialchars($alumni['nisn']); ?></p>
        <p><strong>Jurusan:</strong> <?php echo htmlspecialchars($alumni['jurusan']); ?></p>
        <p><strong>Kelas:</strong> <?php echo htmlspecialchars($alumni['kelas']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($alumni['email']); ?></p>
        <p><strong>No. HP:</strong> <?php echo htmlspecialchars($alumni['no_hp']); ?></p>
        <p><strong>Alamat:</strong> <?php echo htmlspecialchars($alumni['alamat']); ?></p>
        <p><strong>Biodata:</strong> <?php echo htmlspecialchars($alumni['biodata']); ?></p>
        <p><strong>Tempat Lahir:</strong> <?php echo htmlspecialchars($alumni['tempat_lahir']); ?></p>
        <p><strong>Tanggal Lahir:</strong> <?php echo htmlspecialchars($alumni['tanggal_lahir']); ?></p>
        <p><strong>Nama Ayah:</strong> <?php echo htmlspecialchars($alumni['nama_ayah']); ?> (<?php echo htmlspecialchars($alumni['pekerjaan_ayah']); ?>)</p>
        <p><strong>Nama Ibu:</strong> <?php echo htmlspecialchars($alumni['nama_ibu']); ?> (<?php echo htmlspecialchars($alumni['pekerjaan_ibu']); ?>)</p>
        <p><strong>No. HP Orang Tua:</strong> <?php echo htmlspecialchars($alumni['no_hp_ortu']); ?></p>

        <div class="edit-profile">
            <a href="edit-profile.php?id_alumni=<?php echo $alumni['id_alumni']; ?>">Edit Profil</a>
        </div>
    </div>
</section>

<section id="produk" class="section-p1">
    <h2>Alumni Lainnya</h2>
    <p>Temukan alumni lain dari angkatan yang sama</p>
    <div class="pro-container">
    <?php
    // Ambil data alumni lainnya yang berada di angkatan yang sama
    $sql = "SELECT id_alumni, nama, tahun_lulus, foto_profil FROM alumni WHERE tahun_lulus = '{$alumni['tahun_lulus']}' AND id_alumni != '{$alumni['id_alumni']}'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="pro" onclick="window.location.href=\'profil_alumni.php?id_alumni=' . $row["id_alumni"] . '\';">';
            echo '<img src="' . $row["foto_profil"] . '" alt="Foto Alumni">';
            echo '<div class="des">';
            echo '<h5>' . $row["nama"] . '</h5>';
            echo '<span>Tahun Lulus: ' . $row["tahun_lulus"] . '</span>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<p>Belum ada alumni lain dari angkatan ini.</p>";
    }
    ?>
    </div>
</section>
<script>
function toggleProfileSlide() {
    var slide = document.getElementById("profile-slide");
    slide.style.display = slide.style.display === "block" ? "none" : "block";
}
</script>
<style>#awokawok {
    display: flex;
    align-items: center; /* Pusatkan elemen secara vertikal */
    justify-content: space-between; /* Beri jarak antara elemen */
    text-align: center; /* Tengahkan teks */
    padding: 20px;
}

h3, h5, h6 {
    margin: 5px 0; /* Kurangi margin agar tidak terlalu renggang */
}
#header {
    display: flex;
    flex-direction: column; /* Menjadikan anak-anak header dalam susunan vertikal */
    align-items: center; /* Pusatkan isi */
    text-align: center;
    background-color:rgb(67, 68, 69); /* Warna latar header */
    padding-bottom: 10px;
}

#awokawok {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: center;
    width: 100%;
    padding: 20px;
}

#navbar-container {
    width: 100%;
    background-color: #007bff; /* Warna latar navbar */
    text-align: center;
}

#navbar {
    list-style: none;
    padding: 10px;
    margin: 0;
    display: flex;
    justify-content: center;
    gap: 20px; /* Jarak antar menu */
}

#navbar li {
    display: inline;
}

#navbar a {
    text-decoration: none;
    color: white;
    font-size: 16px;
    padding: 10px 15px;
    transition: 0.3s;
}

#navbar a:hover,
#navbar .active {
    background-color: #0056b3; /* Warna saat hover/aktif */
    border-radius: 5px;
}


</style>
</body>
</html>

<?php
mysqli_close($conn);
?>
