function toggleMenuSlide() {
    var slide = document.getElementById("menu-slide");
    slide.classList.toggle("show");
}
document.getElementById("close-menu").addEventListener("click", function() {
    document.getElementById("menu-slide").classList.remove("show");
});

function toggleProfileSlide() {
    var slide = document.getElementById("profile-slide");
    slide.classList.toggle("show");
}
document.getElementById("close-profile").addEventListener("click", function() {
    document.getElementById("profile-slide").classList.remove("show");
});