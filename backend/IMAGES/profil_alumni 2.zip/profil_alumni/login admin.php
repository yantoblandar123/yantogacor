<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login alumni SMA NEGERI 1 MONTONG</title>

    <link rel="stylesheet" href="style.css">
</head>

<body id="login_header">
<header id="header">
        <a href="#"><img src="IMAGES/logo provinsi.png" class="logo" width="150" height="150" alt=""></a>
        <div class="Montong">
            <h3>PEMERINTAH PROVINSI JAWA TIMUR</h3>
            <h3>DINAS PENDIDIKAN</h3>
            <h6>Cabang Dinas Pendidikan Wilayah Bojonegoro</h6>
            <h6>(Kabupaten Bojonegoro-Kabupaten Tuban)</h6>
            <h3>SEKOLAH MENENGAH ATAS NEGERI 1 MONTONG</h3>
            <h5>Jl.Raya Tanggulangin Km 1 Montong Tuban, Telp.(0356)4214568</h5>
            <h6>E-mail : sma_negeri1montong@yahoo.com Website : smansamontong.sch.id</h6>
        </div>
        <a href="#"><img src="IMAGES/logonya.png" class="logo" width="150" height="150" alt=""></a>
    </header>

    <section id="login">
        <div class="login">
            <h1>Login</h1>
            <form action="login1.php" method="post">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <div class="links">
                    <button class="anjay" type="submit">Login</button>
                </div>
            </form>
            <a href="daftar.html"><span>Belum punya akun</span></a>
        </div>
    </section>
    <script src="script.js"></script>
</body>
</html>

